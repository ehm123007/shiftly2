import { Employee, ShiftCategory, ShiftInfo, DaySchedule, RosterChangeLog, ChatMessage, UserNotification, MarketPost } from '../types';

export const SHIFT_DEFINITIONS: Record<ShiftCategory, ShiftInfo> = {
  'Morning': {
    category: 'Morning',
    time: '07:00 – 15:30',
    startTime: '07:00',
    endTime: '15:30',
    maleOnly: false,
    colorBg: 'bg-emerald-50 text-emerald-900 border-emerald-200',
    colorText: 'text-emerald-700',
    icon: 'Sun'
  },
  'Day': {
    category: 'Day',
    time: '10:00 – 18:30',
    startTime: '10:00',
    endTime: '18:30',
    maleOnly: false,
    colorBg: 'bg-sky-50 text-sky-900 border-sky-200',
    colorText: 'text-sky-700',
    icon: 'Clock'
  },
  'Evening': {
    category: 'Evening',
    time: '13:30 – 22:00',
    startTime: '13:30',
    endTime: '22:00',
    maleOnly: false,
    colorBg: 'bg-indigo-50 text-indigo-900 border-indigo-200',
    colorText: 'text-indigo-700',
    icon: 'Sunset'
  },
  'Night': {
    category: 'Night',
    time: '16:00 – 00:00',
    startTime: '16:00',
    endTime: '00:00',
    maleOnly: true, // Prohibited for females (ends after 22:00)
    colorBg: 'bg-amber-50 text-amber-950 border-amber-300',
    colorText: 'text-amber-800',
    icon: 'Moon'
  },
  'Overnight': {
    category: 'Overnight',
    time: '22:30 – 07:30',
    startTime: '22:30',
    endTime: '07:30',
    maleOnly: true, // Prohibited for females (ends after 22:00)
    colorBg: 'bg-purple-950 text-purple-100 border-purple-800',
    colorText: 'text-purple-300',
    icon: 'Sparkles'
  },
  'OFF': {
    category: 'OFF',
    time: 'Rest Day',
    startTime: '00:00',
    endTime: '00:00',
    maleOnly: false,
    colorBg: 'bg-slate-100 text-slate-600 border-slate-200',
    colorText: 'text-slate-500',
    icon: 'Minus'
  },
  'Maternity Leave': {
    category: 'Maternity Leave',
    time: 'Statutory Leave',
    startTime: '00:00',
    endTime: '00:00',
    maleOnly: false,
    isLeave: true,
    isProtected: true, // Non-exchangeable!
    colorBg: 'bg-rose-50 text-rose-900 border-rose-200',
    colorText: 'text-rose-700',
    icon: 'ShieldAlert'
  },
  'Parental Leave': {
    category: 'Parental Leave',
    time: 'Protected Leave',
    startTime: '00:00',
    endTime: '00:00',
    maleOnly: false,
    isLeave: true,
    isProtected: true, // Non-exchangeable!
    colorBg: 'bg-teal-50 text-teal-900 border-teal-200',
    colorText: 'text-teal-700',
    icon: 'HeartHandshake'
  },
  'Annual Leave': {
    category: 'Annual Leave',
    time: 'Approved PTO',
    startTime: '00:00',
    endTime: '00:00',
    maleOnly: false,
    isLeave: true,
    colorBg: 'bg-blue-50 text-blue-900 border-blue-200',
    colorText: 'text-blue-700',
    icon: 'Calendar'
  },
  'Sick Leave': {
    category: 'Sick Leave',
    time: 'Medical Rest',
    startTime: '00:00',
    endTime: '00:00',
    maleOnly: false,
    isLeave: true,
    colorBg: 'bg-orange-50 text-orange-900 border-orange-200',
    colorText: 'text-orange-700',
    icon: 'Cross'
  }
};

export const DEFAULT_DAYS: DaySchedule[] = [
  { date: '2026-09-14', dayName: 'Mon', dayNumber: '14', month: 'Sep' },
  { date: '2026-09-15', dayName: 'Tue', dayNumber: '15', month: 'Sep' },
  { date: '2026-09-16', dayName: 'Wed', dayNumber: '16', month: 'Sep' },
  { date: '2026-09-17', dayName: 'Thu', dayNumber: '17', month: 'Sep' },
  { date: '2026-09-18', dayName: 'Fri', dayNumber: '18', month: 'Sep' },
  { date: '2026-09-19', dayName: 'Sat', dayNumber: '19', month: 'Sep' },
  { date: '2026-09-20', dayName: 'Sun', dayNumber: '20', month: 'Sep' },
];

export const DEFAULT_EMPLOYEES: Employee[] = [
  {
    id: 'EMP-41055',
    name: 'Emdadul Haque',
    gender: 'male',
    initials: 'EH',
    role: 'Senior Operations Representative',
    department: 'Priority Client Services',
    phone: '+880 1873-380007',
    email: 'e.haque@shiftly.corp',
    schedule: ['Night', 'Night', 'Day', 'OFF', 'Night', 'Night', 'OFF'],
    timings: ['16:00 – 24:00', '16:00 – 24:00', '10:00 – 18:30', 'Rest Day', '16:00 – 24:00', '16:00 – 24:00', 'Rest Day'],
    extraHours: [2, 0, 0, 0, 3, 0, 0], // Extra hours paid overtime
    protectedLeaves: [null, null, null, null, null, null, null]
  },
  {
    id: 'EMP-41062',
    name: 'Farah Rahman',
    gender: 'female',
    initials: 'FR',
    role: 'Customer Operations Executive',
    department: 'Retail Cards & Dispute Help',
    phone: '+880 1711-224466',
    email: 'farah.rahman@shiftly.corp',
    schedule: ['Morning', 'OFF', 'Evening', 'Day', 'OFF', 'Evening', 'OFF'],
    timings: ['07:00 – 15:30', 'Rest Day', '13:30 – 22:00', '10:00 – 18:30', 'Rest Day', '13:30 – 22:00', 'Rest Day'],
    extraHours: [0, 0, 2, 0, 0, 0, 0],
    protectedLeaves: [null, null, null, null, null, null, null]
  },
  {
    id: 'EMP-39218',
    name: 'Saad Ahmed',
    gender: 'male',
    initials: 'SA',
    role: 'Customer Operations Specialist',
    department: 'Fraud Prevention & Risk Desk',
    phone: '+880 1819-335577',
    email: 'saad.ahmed@shiftly.corp',
    schedule: ['Morning', 'Day', 'OFF', 'Night', 'Night', 'OFF', 'Day'],
    timings: ['07:00 – 15:30', '10:00 – 18:30', 'Rest Day', '16:00 – 24:00', '16:00 – 24:00', 'Rest Day', '10:00 – 18:30'],
    extraHours: [0, 2, 0, 0, 2, 0, 0],
    protectedLeaves: [null, null, null, null, null, null, null]
  },
  {
    id: 'EMP-45077',
    name: 'Neela Chowdhury',
    gender: 'female',
    initials: 'NC',
    role: 'Senior Customer Service Lead',
    department: 'Digital Platform Support',
    phone: '+880 1912-998877',
    email: 'neela.chowdhury@shiftly.corp',
    schedule: ['Day', 'Morning', 'OFF', 'Morning', 'Day', 'Evening', 'Morning'],
    timings: ['10:00 – 18:30', '07:00 – 15:30', 'Rest Day', '07:00 – 15:30', '10:00 – 18:30', '13:30 – 22:00', '07:00 – 15:30'],
    extraHours: [0, 0, 0, 0, 0, 1.5, 0],
    protectedLeaves: [null, null, null, null, null, null, null]
  },
  {
    id: 'EMP-43819',
    name: 'Imran Hossain',
    gender: 'male',
    initials: 'IH',
    role: 'Operations Officer',
    department: 'Remittance & Global Desk',
    phone: '+880 1622-445566',
    email: 'imran.hossain@shiftly.corp',
    schedule: ['OFF', 'Day', 'Morning', 'Evening', 'Overnight', 'Morning', 'Day'],
    timings: ['Rest Day', '10:00 – 18:30', '07:00 – 15:30', '13:30 – 22:00', '22:30 – 07:30', '07:00 – 15:30', '10:00 – 18:30'],
    extraHours: [0, 0, 0, 0, 4, 0, 0],
    protectedLeaves: [null, null, null, null, null, null, null]
  },
  {
    id: 'EMP-42139',
    name: 'Kabir Hasan',
    gender: 'male',
    initials: 'KH',
    role: 'Tier-2 Technical Specialist',
    department: 'Merchant Services Unit',
    phone: '+880 1733-112233',
    email: 'kabir.hasan@shiftly.corp',
    schedule: ['Morning', 'Evening', 'OFF', 'Day', 'Morning', 'Night', 'Morning'],
    timings: ['07:00 – 15:30', '13:30 – 22:00', 'Rest Day', '10:00 – 18:30', '07:00 – 15:30', '16:00 – 24:00', '07:00 – 15:30'],
    extraHours: [0, 0, 0, 2, 0, 0, 0],
    protectedLeaves: [null, null, null, null, null, null, null]
  },
  {
    id: 'EMP-46026',
    name: 'Tania Islam',
    gender: 'female',
    initials: 'TI',
    role: 'Resolution Specialist',
    department: 'Client Escalation Care',
    phone: '+880 1844-556677',
    email: 'tania.islam@shiftly.corp',
    // Tania has Thursday as Maternity/Parental leave, which CANNOT be exchanged!
    schedule: ['Morning', 'OFF', 'Morning', 'Parental Leave', 'Evening', 'Day', 'Morning'],
    timings: ['07:00 – 15:30', 'Rest Day', '07:00 – 15:30', 'Protected Leave', '13:30 – 22:00', '10:00 – 18:30', '07:00 – 15:30'],
    extraHours: [0, 0, 0, 0, 0, 0, 0],
    protectedLeaves: [null, null, null, 'Parental Leave', null, null, null]
  },
  {
    id: 'EMP-47550',
    name: 'Rafi Sarker',
    gender: 'male',
    initials: 'RS',
    role: 'Operations Specialist',
    department: 'Customer Care & Escalations',
    phone: '+880 1955-889900',
    email: 'rafi.sarker@shiftly.corp',
    schedule: ['Morning', 'Morning', 'Day', 'Night', 'Morning', 'OFF', 'Day'],
    timings: ['07:00 – 15:30', '07:00 – 15:30', '10:00 – 18:30', '16:00 – 24:00', '07:00 – 15:30', 'Rest Day', '10:00 – 18:30'],
    extraHours: [1.5, 0, 0, 0, 0, 0, 0],
    protectedLeaves: [null, null, null, null, null, null, null]
  }
];

export const DEFAULT_AUDIT_LOGS: RosterChangeLog[] = [
  {
    id: 'log-01',
    timestamp: '2026-09-10T14:20:00Z',
    changedBy: 'Admin Moderator',
    changeType: 'File Roster Upload',
    employeeId: 'ALL',
    employeeName: 'All 8 Team Staff Members',
    date: '2026-09-14 to 2026-09-20',
    previousShift: 'Draft Roster',
    newShift: 'Published Official Roster',
    reason: 'Weekly workforce roster published for review',
    status: 'Applied'
  },
  {
    id: 'log-02',
    timestamp: '2026-09-11T09:15:00Z',
    changedBy: 'Emdadul Haque',
    changeType: 'Extra Hours (EH)',
    employeeId: 'EMP-41055',
    employeeName: 'Emdadul Haque',
    date: '2026-09-14',
    previousShift: 'Night (0h EH)',
    newShift: 'Night (+2h EH)',
    extraHoursDiff: 2,
    reason: 'Approved peak volume surge coverage',
    status: 'Applied'
  }
];

export const DEFAULT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    conversationId: 'emp-41055_emp-41062',
    senderId: 'EMP-41062',
    senderName: 'Farah Rahman',
    senderInitials: 'FR',
    recipientId: 'EMP-41055',
    text: 'Hi Emdadul, can we talk about Wednesday’s roster? I have an evening shift 13:30–22:00.',
    timestamp: '2026-09-11T10:14:00Z',
    shiftAttachment: {
      date: '2026-09-16',
      shift: 'Evening',
      timing: '13:30 – 22:00',
      note: 'Need to adjust timing due to family appointment'
    }
  },
  {
    id: 'msg-2',
    conversationId: 'emp-41055_emp-41062',
    senderId: 'EMP-41055',
    senderName: 'Emdadul Haque',
    senderInitials: 'EH',
    recipientId: 'EMP-41062',
    text: 'Hey Farah, I’m scheduled for Day (10:00–18:30) on Wednesday. Let me check the shift swap options on our board.',
    timestamp: '2026-09-11T10:18:00Z'
  },
  {
    id: 'msg-3',
    conversationId: 'emp-41055_emp-39218',
    senderId: 'EMP-39218',
    senderName: 'Saad Ahmed',
    senderInitials: 'SA',
    recipientId: 'EMP-41055',
    text: 'Are you taking extra hours (EH) on Monday night? If you want to trade +2h EH on Friday, let me know!',
    timestamp: '2026-09-11T11:05:00Z'
  }
];

export const DEFAULT_NOTIFICATIONS: UserNotification[] = [
  {
    id: 'notif-1',
    userId: 'EMP-41055',
    title: 'Roster Schedule Published',
    message: 'Week of 14–20 Sep roster has been published by Admin Moderator.',
    timestamp: '2026-09-10T14:20:00Z',
    read: true,
    type: 'roster-updated',
    actionView: 'roster'
  },
  {
    id: 'notif-2',
    userId: 'EMP-41055',
    title: 'Paid Extra Hours (EH) Confirmed',
    message: 'Your +2.0 EH extra hours on Monday 14-Sep have been approved.',
    timestamp: '2026-09-11T09:15:00Z',
    read: false,
    type: 'eh-alert',
    actionView: 'roster'
  },
  {
    id: 'notif-3',
    userId: 'EMP-41055',
    title: 'New Message from Farah Rahman',
    message: 'Farah sent a message regarding Wednesday shift coordination.',
    timestamp: '2026-09-11T10:14:00Z',
    read: false,
    type: 'message',
    actionView: 'messages'
  }
];

export const DEFAULT_MARKET_POSTS: MarketPost[] = [
  {
    id: 'post-1',
    authorId: 'EMP-41062',
    authorName: 'Farah Rahman',
    authorInitials: 'FR',
    authorGender: 'female',
    authorRole: 'Customer Operations Executive',
    type: 'desire-day-off',
    targetDate: '2026-09-16',
    targetDateIndex: 2, // Wednesday
    currentShift: 'Evening',
    currentTiming: '13:30 – 22:00',
    desiredShift: 'OFF',
    willingToOffer: 'Willing to take Saturday Evening (Sep 19) or cover any Morning shift',
    offeredDateIndex: 5,
    offeredDate: '2026-09-19',
    offeredShift: 'Evening',
    offeredTiming: '13:30 – 22:00',
    note: 'Family emergency on Wednesday afternoon. Need this day off urgently.',
    createdAt: '2026-09-11T09:30:00Z',
    status: 'open'
  },
  {
    id: 'post-2',
    authorId: 'EMP-39218',
    authorName: 'Saad Ahmed',
    authorInitials: 'SA',
    authorGender: 'male',
    authorRole: 'Customer Operations Specialist',
    type: 'desire-work-shift',
    targetDate: '2026-09-16',
    targetDateIndex: 2, // Wednesday
    currentShift: 'OFF',
    currentTiming: 'Rest Day',
    desiredShift: 'Day',
    desiredTiming: '10:00 – 18:30',
    willingToOffer: 'Willing to give up Wednesday rest day in exchange for Thursday or Friday off',
    offeredDateIndex: 3,
    offeredDate: '2026-09-17',
    note: 'Looking to pick up an active Day shift on Wednesday.',
    createdAt: '2026-09-11T10:15:00Z',
    status: 'open'
  },
  {
    id: 'post-3',
    authorId: 'EMP-45077',
    authorName: 'Neela Chowdhury',
    authorInitials: 'NC',
    authorGender: 'female',
    authorRole: 'Senior Customer Service Lead',
    type: 'desire-day-off',
    targetDate: '2026-09-17',
    targetDateIndex: 3, // Thursday
    currentShift: 'Morning',
    currentTiming: '07:00 – 15:30',
    desiredShift: 'OFF',
    willingToOffer: 'Willing to cover Friday (Sep 18) Day shift or trade Sunday',
    offeredDateIndex: 4,
    offeredDate: '2026-09-18',
    offeredShift: 'Day',
    offeredTiming: '10:00 – 18:30',
    note: 'Need Thursday off for medical exam. Happy to swap with anyone on duty.',
    createdAt: '2026-09-11T11:00:00Z',
    status: 'open'
  },
  {
    id: 'post-4',
    authorId: 'EMP-43819',
    authorName: 'Kamrul Hasan',
    authorInitials: 'KH',
    authorGender: 'male',
    authorRole: 'Operations Officer',
    type: 'desire-work-shift',
    targetDate: '2026-09-19',
    targetDateIndex: 5, // Saturday
    currentShift: 'OFF',
    currentTiming: 'Rest Day',
    desiredShift: 'Overnight',
    desiredTiming: '22:30 – 07:30',
    willingToOffer: 'Happy to cover Saturday night/overnight shift for anyone wanting weekend rest',
    note: 'Available for weekend overnight coverage.',
    createdAt: '2026-09-11T11:45:00Z',
    status: 'open'
  }
];
