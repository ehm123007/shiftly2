import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LoginView } from './components/LoginView';
import { PersonalBoard } from './components/PersonalBoard';
import { RosterView } from './components/RosterView';
import { SwapModal } from './components/SwapModal';
import { SwapDeskView } from './components/SwapDeskView';
import { MessagesView } from './components/MessagesView';
import { AuditLogView } from './components/AuditLogView';
import { AdminPortal } from './components/AdminPortal';
import { TeamAvailability } from './components/TeamAvailability';
import { NotificationCenter } from './components/NotificationCenter';
import { NotificationToast } from './components/NotificationToast';
import { MarketView } from './components/MarketView';

import { 
  Employee, 
  DaySchedule, 
  SwapRequest, 
  RosterChangeLog, 
  ChatMessage, 
  UserNotification, 
  SwapPlan, 
  ShiftCategory,
  MarketPost,
  MarketMatchOption
} from './types';
import { SHIFT_DEFINITIONS } from './data/defaultData';
import { calculateExtraHoursForShift } from './utils/rosterEngine';

import { 
  loadEmployees, 
  saveEmployees, 
  loadDays, 
  saveDays, 
  loadRequests, 
  saveRequests, 
  loadAuditLogs, 
  saveAuditLogs, 
  loadMessages, 
  saveMessages, 
  loadNotifications, 
  saveNotifications, 
  loadMarketPosts,
  saveMarketPosts,
  loadSession, 
  saveSession, 
  logRosterChange, 
  resetAllData 
} from './utils/storage';

export default function App() {
  // Global persistent states
  const [employees, setEmployees] = useState<Employee[]>(loadEmployees);
  const [days, setDays] = useState<DaySchedule[]>(loadDays);
  const [swapRequests, setSwapRequests] = useState<SwapRequest[]>(loadRequests);
  const [auditLogs, setAuditLogs] = useState<RosterChangeLog[]>(loadAuditLogs);
  const [messages, setMessages] = useState<ChatMessage[]>(loadMessages);
  const [notifications, setNotifications] = useState<UserNotification[]>(loadNotifications);
  const [marketPosts, setMarketPosts] = useState<MarketPost[]>(loadMarketPosts);

  // Active toast alert for real-time visual feedback
  const [activeToast, setActiveToast] = useState<UserNotification | null>(null);

  // User session
  const [session, setSession] = useState<{ userId: string; role: 'employee' | 'admin' } | null>(loadSession);
  
  // Navigation & UI state
  const [activeView, setActiveView] = useState<string>('board');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Swap modal configuration
  const [swapModalConfig, setSwapModalConfig] = useState<{
    isOpen: boolean;
    dayIndex: number;
    tab: 'day-off' | 'timing-change' | 'eh-claim';
  }>({
    isOpen: false,
    dayIndex: 2,
    tab: 'timing-change'
  });

  // Keep storage synced when states change
  useEffect(() => {
    saveEmployees(employees);
  }, [employees]);

  useEffect(() => {
    saveDays(days);
  }, [days]);

  useEffect(() => {
    saveRequests(swapRequests);
  }, [swapRequests]);

  useEffect(() => {
    saveAuditLogs(auditLogs);
  }, [auditLogs]);

  useEffect(() => {
    saveMessages(messages);
  }, [messages]);

  useEffect(() => {
    saveNotifications(notifications);
  }, [notifications]);

  useEffect(() => {
    saveMarketPosts(marketPosts);
  }, [marketPosts]);

  useEffect(() => {
    saveSession(session);
  }, [session]);

  // Determine active employee
  const currentEmployee = employees.find(e => e.id === session?.userId) || employees[0];
  const userRole = session?.role || 'employee';

  // Counts
  const relevantNotifs = notifications.filter(n => 
    userRole === 'admin' 
      ? (n.userId === 'ADMIN' || n.userId === currentEmployee?.id || n.userId === 'ALL')
      : (n.userId === currentEmployee?.id || n.userId === 'ALL')
  );
  const unreadNotifsCount = relevantNotifs.filter(n => !n.read).length;
  const unreadMessagesCount = messages.filter(m => m.recipientId === currentEmployee?.id).length;
  const pendingRequestsCount = swapRequests.filter(r => r.state === 'Pending' && (userRole === 'admin' || r.participantIds.includes(currentEmployee?.id))).length;
  const openMarketPostsCount = marketPosts.filter(p => p.status === 'open').length;

  // Log in as employee via Bank ID
  const handleLoginEmployee = (employeeId: string) => {
    setSession({ userId: employeeId, role: 'employee' });
    setActiveView('board');
  };

  // Log in as Admin - Password check without exposing plain text in UI
  const handleLoginAdmin = (user: string, pass: string): boolean => {
    if (user.toLowerCase() === 'admin' && pass === 'haque@123007') {
      setSession({ userId: employees[0].id, role: 'admin' });
      setActiveView('admin');
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    setSession(null);
    setActiveView('board');
  };

  const handleToggleRole = () => {
    if (!session) return;
    const nextRole = session.role === 'admin' ? 'employee' : 'admin';
    setSession({ ...session, role: nextRole });
    if (nextRole === 'admin') {
      setActiveView('admin');
    } else {
      setActiveView('board');
    }
  };

  const handleMarkNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const handleMarkOneNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleDeleteOneNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const handleClearAllNotifications = () => {
    if (userRole === 'admin') {
      setNotifications(prev => prev.filter(n => n.userId !== 'ADMIN' && n.userId !== currentEmployee.id));
    } else {
      setNotifications(prev => prev.filter(n => n.userId !== currentEmployee.id));
    }
  };

  // Open Swap Modal helper
  const handleOpenSwapModal = (dayIndex: number, defaultTab: 'day-off' | 'timing-change' | 'eh-claim' = 'timing-change') => {
    setSwapModalConfig({
      isOpen: true,
      dayIndex,
      tab: defaultTab
    });
  };

  // Submit a circular swap or peer timing trade proposal
  const handleSubmitPlan = (plan: SwapPlan, reason: string) => {
    const me = currentEmployee;
    const participants = plan.members.map(id => employees.find(e => e.id === id)?.name || id);

    const newReq: SwapRequest = {
      id: `req-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      requesterId: me.id,
      requesterName: me.name,
      type: plan.type === 'timing-change' ? 'timing-change' : 'day-off',
      targetDateIndex: plan.transfers[0]?.dateIndex ?? 0,
      targetDate: plan.transfers[0]?.date ?? days[0].date,
      currentShift: plan.transfers[0]?.fromShift ?? 'Day',
      currentTiming: plan.transfers[0]?.fromTiming ?? 'Standard',
      participants,
      participantIds: plan.members,
      approvedByIds: [me.id], // Initiator implicitly approves
      plan,
      reason,
      createdAt: new Date().toISOString(),
      state: plan.members.length === 1 ? 'Approved' : 'Pending'
    };

    // If 1-person or immediately approved, apply mutations
    if (newReq.state === 'Approved') {
      applyTransfers(plan.transfers, reason);
    }

    setSwapRequests(prev => [newReq, ...prev]);

    // 1. Send notification to other participating employees
    const createdNotifs: UserNotification[] = [];
    plan.members.forEach(memberId => {
      if (memberId !== me.id) {
        createdNotifs.push({
          id: `notif-${Date.now()}-${memberId}`,
          userId: memberId,
          title: 'New Swap Proposal on Swap Desk',
          message: `${me.name} proposed a shift trade (${plan.description}). Please review on Swap Desk.`,
          timestamp: new Date().toISOString(),
          read: false,
          type: 'swap-request',
          actionView: 'swaps',
          metadata: {
            employeeId: me.id,
            employeeName: me.name,
            date: plan.transfers[0]?.date
          }
        });
      }
    });

    // 2. REQUIREMENT: Admins should receive notifications for all roster modifications
    const adminAlert: UserNotification = {
      id: `admin-notif-swap-${Date.now()}`,
      userId: 'ADMIN',
      title: 'Admin Alert: Roster Swap Proposed',
      message: `${me.name} (${me.id}) initiated a shift swap on ${plan.transfers[0]?.date || 'Schedule'}. Team rotation: ${plan.description}`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'admin-alert',
      actionView: 'swaps',
      metadata: {
        employeeId: me.id,
        employeeName: me.name,
        date: plan.transfers[0]?.date
      }
    };
    createdNotifs.push(adminAlert);

    // Confirmation toast for the user
    const userToast: UserNotification = {
      id: `toast-${Date.now()}`,
      userId: me.id,
      title: 'Swap Proposal Dispatched',
      message: `Your trade proposal (${plan.description}) was broadcast to teammates and logged with administration.`,
      timestamp: new Date().toISOString(),
      read: true,
      type: 'swap-request',
      actionView: 'swaps'
    };
    setActiveToast(userToast);

    setNotifications(prev => [...createdNotifs, ...prev]);

    // Notify Admin & log roster change
    logRosterChange({
      changedBy: me.name,
      changeType: 'Shift Swap',
      employeeId: me.id,
      employeeName: me.name,
      date: plan.transfers[0]?.date || 'Schedule',
      previousShift: plan.transfers[0]?.fromShift || 'Current',
      newShift: 'Swap Requested',
      reason: `Proposal submitted: ${plan.description}`
    });
    setAuditLogs(loadAuditLogs());
  };

  // Direct Timing Change Handler
  const handleDirectTimingChange = (dayIndex: number, newShift: ShiftCategory, newTiming: string, reason: string) => {
    const me = currentEmployee;
    const prevShift = me.schedule[dayIndex];
    const prevTiming = me.timings[dayIndex];
    const dateStr = days[dayIndex]?.date || `Day ${dayIndex + 1}`;

    const updated = employees.map(emp => {
      if (emp.id === me.id) {
        const nextSchedule = [...emp.schedule];
        const nextTimings = [...emp.timings];
        const nextEH = [...emp.extraHours];
        nextSchedule[dayIndex] = newShift;
        nextTimings[dayIndex] = newTiming;
        // Quietly calculate overnight extra hours without mentioning in UI
        nextEH[dayIndex] = calculateExtraHoursForShift(newShift, newTiming, emp.extraHours[dayIndex]);
        return {
          ...emp,
          schedule: nextSchedule,
          timings: nextTimings,
          extraHours: nextEH
        };
      }
      return emp;
    });

    setEmployees(updated);

    // 1. Employee Confirmation
    const userNotif: UserNotification = {
      id: `notif-timing-${Date.now()}`,
      userId: me.id,
      title: 'Shift Timing Updated',
      message: `Your shift on ${dateStr} changed from ${prevShift} (${prevTiming}) to ${newShift} (${newTiming}).`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'roster-updated',
      actionView: 'roster',
      metadata: {
        date: dateStr,
        previousShift: prevShift,
        newShift
      }
    };

    // 2. REQUIREMENT: Admins should receive notifications for all roster modifications
    const adminAlert: UserNotification = {
      id: `admin-alert-timing-${Date.now()}`,
      userId: 'ADMIN',
      title: 'Admin Alert: Shift Timing Modified',
      message: `${me.name} (${me.id}) modified their shift on ${dateStr} to ${newShift} (${newTiming}). Reason: "${reason}".`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'admin-alert',
      actionView: 'history',
      metadata: {
        employeeId: me.id,
        employeeName: me.name,
        date: dateStr,
        previousShift: prevShift,
        newShift
      }
    };

    setActiveToast(userNotif);
    setNotifications(prev => [userNotif, adminAlert, ...prev]);

    logRosterChange({
      changedBy: me.name,
      changeType: 'Timing Change',
      employeeId: me.id,
      employeeName: me.name,
      date: dateStr,
      previousShift: prevShift,
      newShift,
      previousTiming: prevTiming,
      newTiming,
      reason
    });
    setAuditLogs(loadAuditLogs());
  };

  // Swap shift timing with a colleague on that day's available shifts
  const handleSwapColleagueShift = (dayIndex: number, targetColleague: Employee, reason: string) => {
    const me = currentEmployee;
    const dateStr = days[dayIndex]?.date || `Day ${dayIndex + 1}`;
    const myCurrentShift = me.schedule[dayIndex];
    const myCurrentTiming = me.timings[dayIndex];
    const colleagueCurrentShift = targetColleague.schedule[dayIndex];
    const colleagueCurrentTiming = targetColleague.timings[dayIndex];

    const updated = employees.map(emp => {
      if (emp.id === me.id) {
        const nextSchedule = [...emp.schedule];
        const nextTimings = [...emp.timings];
        const nextEH = [...emp.extraHours];
        nextSchedule[dayIndex] = colleagueCurrentShift;
        nextTimings[dayIndex] = colleagueCurrentTiming;
        nextEH[dayIndex] = calculateExtraHoursForShift(colleagueCurrentShift, colleagueCurrentTiming, emp.extraHours[dayIndex]);
        return { ...emp, schedule: nextSchedule, timings: nextTimings, extraHours: nextEH };
      }
      if (emp.id === targetColleague.id) {
        const nextSchedule = [...emp.schedule];
        const nextTimings = [...emp.timings];
        const nextEH = [...emp.extraHours];
        nextSchedule[dayIndex] = myCurrentShift;
        nextTimings[dayIndex] = myCurrentTiming;
        nextEH[dayIndex] = calculateExtraHoursForShift(myCurrentShift, myCurrentTiming, emp.extraHours[dayIndex]);
        return { ...emp, schedule: nextSchedule, timings: nextTimings, extraHours: nextEH };
      }
      return emp;
    });

    setEmployees(updated);

    // Notifications
    const meNotif: UserNotification = {
      id: `notif-timing-swap-${Date.now()}-me`,
      userId: me.id,
      title: 'Shift Timing Exchanged',
      message: `Shifted timing with ${targetColleague.name} on ${dateStr}. You are now on ${colleagueCurrentShift} (${colleagueCurrentTiming}).`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'roster-updated',
      actionView: 'roster'
    };

    const colleagueNotif: UserNotification = {
      id: `notif-timing-swap-${Date.now()}-colleague`,
      userId: targetColleague.id,
      title: 'Shift Timing Exchanged',
      message: `${me.name} shifted timings with you on ${dateStr}. You are now on ${myCurrentShift} (${myCurrentTiming}).`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'roster-updated',
      actionView: 'roster'
    };

    const adminAlert: UserNotification = {
      id: `admin-alert-shift-swap-${Date.now()}`,
      userId: 'ADMIN',
      title: 'Admin Alert: Shift Timing Swapped',
      message: `${me.name} (${me.id}) and ${targetColleague.name} (${targetColleague.id}) shifted timings on ${dateStr}. ${myCurrentShift} ↔ ${colleagueCurrentShift}. Reason: "${reason}".`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'admin-alert',
      actionView: 'history'
    };

    setActiveToast(meNotif);
    setNotifications(prev => [meNotif, colleagueNotif, adminAlert, ...prev]);

    logRosterChange({
      changedBy: me.name,
      changeType: 'Shift Swap',
      employeeId: me.id,
      employeeName: me.name,
      date: dateStr,
      previousShift: myCurrentShift,
      newShift: colleagueCurrentShift,
      previousTiming: myCurrentTiming,
      newTiming: colleagueCurrentTiming,
      reason: `Shifted timing with ${targetColleague.name}: ${reason}`
    });

    logRosterChange({
      changedBy: me.name,
      changeType: 'Shift Swap',
      employeeId: targetColleague.id,
      employeeName: targetColleague.name,
      date: dateStr,
      previousShift: colleagueCurrentShift,
      newShift: myCurrentShift,
      previousTiming: colleagueCurrentTiming,
      newTiming: myCurrentTiming,
      reason: `Shifted timing with ${me.name}: ${reason}`
    });

    setAuditLogs(loadAuditLogs());
  };

  // Adjust EH (Extra Hours) Handler
  const handleAdjustEH = (dayIndex: number, extraHours: number, reason: string) => {
    const me = currentEmployee;
    const prevEH = me.extraHours[dayIndex] || 0;
    const dateStr = days[dayIndex]?.date || `Day ${dayIndex + 1}`;
    const diff = extraHours - prevEH;

    const updated = employees.map(emp => {
      if (emp.id === me.id) {
        const nextEH = [...emp.extraHours];
        nextEH[dayIndex] = extraHours;
        return {
          ...emp,
          extraHours: nextEH
        };
      }
      return emp;
    });

    setEmployees(updated);

    // 1. User Notification
    const userNotif: UserNotification = {
      id: `notif-eh-${Date.now()}`,
      userId: me.id,
      title: 'Extra Hours (EH) Adjusted',
      message: `Your paid Extra Hours on ${dateStr} were set to ${extraHours}h (${diff >= 0 ? '+' : ''}${diff}h).`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'eh-alert',
      actionView: 'roster',
      metadata: {
        date: dateStr,
        extraHoursDiff: diff
      }
    };

    // 2. REQUIREMENT: Admins should receive notifications for all roster modifications
    const adminAlert: UserNotification = {
      id: `admin-alert-eh-${Date.now()}`,
      userId: 'ADMIN',
      title: 'Admin Alert: Extra Hours (EH) Modification',
      message: `${me.name} (${me.id}) adjusted paid Extra Hours on ${dateStr} by ${diff >= 0 ? '+' : ''}${diff}h (New total: ${extraHours}h EH). Reason: "${reason}".`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'admin-alert',
      actionView: 'history',
      metadata: {
        employeeId: me.id,
        employeeName: me.name,
        date: dateStr,
        extraHoursDiff: diff
      }
    };

    setActiveToast(userNotif);
    setNotifications(prev => [userNotif, adminAlert, ...prev]);

    logRosterChange({
      changedBy: me.name,
      changeType: 'Extra Hours (EH)',
      employeeId: me.id,
      employeeName: me.name,
      date: dateStr,
      previousShift: `${prevEH > 0 ? `+${prevEH}h EH` : '0h EH'}`,
      newShift: `${extraHours > 0 ? `+${extraHours}h EH` : '0h EH'}`,
      extraHoursDiff: diff,
      reason
    });
    setAuditLogs(loadAuditLogs());
  };

  // Helper to apply transfers to the employee schedule
  const applyTransfers = (transfers: any[], reason: string) => {
    setEmployees(prevEmployees => {
      const nextEmployees = structuredClone(prevEmployees);

      transfers.forEach(t => {
        const fromEmp = nextEmployees.find((e: Employee) => e.id === t.fromEmployeeId);
        const toEmp = nextEmployees.find((e: Employee) => e.id === t.toEmployeeId);

        if (fromEmp && toEmp) {
          fromEmp.schedule[t.dateIndex] = t.toShift;
          fromEmp.timings[t.dateIndex] = t.toTiming;
          fromEmp.extraHours[t.dateIndex] = calculateExtraHoursForShift(t.toShift, t.toTiming, fromEmp.extraHours[t.dateIndex]);

          toEmp.schedule[t.dateIndex] = t.fromShift;
          toEmp.timings[t.dateIndex] = t.fromTiming;
          toEmp.extraHours[t.dateIndex] = calculateExtraHoursForShift(t.fromShift, t.fromTiming, toEmp.extraHours[t.dateIndex]);

          logRosterChange({
            changedBy: currentEmployee.name,
            changeType: 'Shift Swap',
            employeeId: fromEmp.id,
            employeeName: fromEmp.name,
            date: t.date,
            previousShift: t.fromShift,
            newShift: t.toShift,
            previousTiming: t.fromTiming,
            newTiming: t.toTiming,
            reason
          });
        }
      });

      return nextEmployees;
    });
    setAuditLogs(loadAuditLogs());
  };

  // Shift Market handlers
  const handleCreateMarketPost = (newPostData: Omit<MarketPost, 'id' | 'createdAt' | 'status'>) => {
    const newPost: MarketPost = {
      ...newPostData,
      id: `market-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      createdAt: new Date().toISOString(),
      status: 'open'
    };

    setMarketPosts(prev => [newPost, ...prev]);

    // Admin alert
    const adminAlert: UserNotification = {
      id: `admin-market-${Date.now()}`,
      userId: 'ADMIN',
      title: 'Admin Alert: New Shift Market Listing',
      message: `${newPost.authorName} (${newPost.authorId}) posted a ${newPost.type === 'desire-day-off' ? 'Day Off request' : 'Working Day request'} on ${newPost.targetDate}.`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'admin-alert',
      actionView: 'market'
    };

    const toast: UserNotification = {
      id: `toast-market-${Date.now()}`,
      userId: newPost.authorId,
      title: 'Listing Published',
      message: 'Your shift market request is live on the community board.',
      timestamp: new Date().toISOString(),
      read: true,
      type: 'system',
      actionView: 'market'
    };

    setActiveToast(toast);
    setNotifications(prev => [adminAlert, ...prev]);
  };

  const handleMatchMarketPost = (postId: string, matchOption: MarketMatchOption) => {
    const post = marketPosts.find(p => p.id === postId);
    if (!post) return;

    const me = currentEmployee;
    const author = employees.find(e => e.id === post.authorId);
    if (!author) return;

    const dayIndex = post.targetDateIndex;
    const dateStr = post.targetDate;

    // Apply the schedule trade
    const updated = employees.map(emp => {
      if (emp.id === me.id) {
        const nextSchedule = [...emp.schedule];
        const nextTimings = [...emp.timings];
        const nextEH = [...emp.extraHours];
        nextSchedule[dayIndex] = matchOption.userReceivesShift as ShiftCategory;
        const def = SHIFT_DEFINITIONS[matchOption.userReceivesShift as ShiftCategory];
        nextTimings[dayIndex] = def?.time || 'Rest Day';
        nextEH[dayIndex] = calculateExtraHoursForShift(matchOption.userReceivesShift as ShiftCategory, nextTimings[dayIndex], emp.extraHours[dayIndex]);
        return { ...emp, schedule: nextSchedule, timings: nextTimings, extraHours: nextEH };
      }
      if (emp.id === author.id) {
        const nextSchedule = [...emp.schedule];
        const nextTimings = [...emp.timings];
        const nextEH = [...emp.extraHours];
        nextSchedule[dayIndex] = matchOption.userGivesShift as ShiftCategory;
        const def = SHIFT_DEFINITIONS[matchOption.userGivesShift as ShiftCategory];
        nextTimings[dayIndex] = def?.time || 'Rest Day';
        nextEH[dayIndex] = calculateExtraHoursForShift(matchOption.userGivesShift as ShiftCategory, nextTimings[dayIndex], emp.extraHours[dayIndex]);
        return { ...emp, schedule: nextSchedule, timings: nextTimings, extraHours: nextEH };
      }
      return emp;
    });

    setEmployees(updated);

    // Update post status
    setMarketPosts(prev => prev.map(p => p.id === postId ? {
      ...p,
      status: 'matched',
      matchedWithId: me.id,
      matchedWithName: me.name
    } : p));

    // Notifications
    const meNotif: UserNotification = {
      id: `notif-match-${Date.now()}-me`,
      userId: me.id,
      title: 'Market Swap Executed',
      message: `Matched request with ${author.name} for ${dateStr}. Shift updated to ${matchOption.userReceivesShift}.`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'roster-updated',
      actionView: 'roster'
    };

    const authorNotif: UserNotification = {
      id: `notif-match-${Date.now()}-author`,
      userId: author.id,
      title: 'Market Request Matched!',
      message: `${me.name} matched your listing for ${dateStr}! Your shift updated to ${matchOption.userGivesShift}.`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'roster-updated',
      actionView: 'roster'
    };

    const adminAlert: UserNotification = {
      id: `admin-alert-match-${Date.now()}`,
      userId: 'ADMIN',
      title: 'Admin Alert: Market Swap Matched',
      message: `${me.name} matched ${author.name}'s listing on ${dateStr}. ${matchOption.pathDescription}`,
      timestamp: new Date().toISOString(),
      read: false,
      type: 'admin-alert',
      actionView: 'history'
    };

    setActiveToast(meNotif);
    setNotifications(prev => [meNotif, authorNotif, adminAlert, ...prev]);

    // Audit logs
    logRosterChange({
      changedBy: me.name,
      changeType: 'Market Match',
      employeeId: me.id,
      employeeName: me.name,
      date: dateStr,
      previousShift: matchOption.userGivesShift,
      newShift: matchOption.userReceivesShift,
      reason: `Matched market request with ${author.name}: ${matchOption.pathDescription}`
    });

    logRosterChange({
      changedBy: me.name,
      changeType: 'Market Match',
      employeeId: author.id,
      employeeName: author.name,
      date: dateStr,
      previousShift: matchOption.userReceivesShift,
      newShift: matchOption.userGivesShift,
      reason: `Matched by ${me.name}: ${matchOption.pathDescription}`
    });

    setAuditLogs(loadAuditLogs());
  };

  const handleCloseMarketPost = (postId: string) => {
    setMarketPosts(prev => prev.map(p => p.id === postId ? { ...p, status: 'closed' } : p));
  };

  // Approve swap request
  const handleApproveRequest = (requestId: string) => {
    const req = swapRequests.find(r => r.id === requestId);
    if (!req) return;

    const me = currentEmployee;
    const isModerator = userRole === 'admin';
    const nextApproved = req.approvedByIds.includes(me.id) ? req.approvedByIds : [...req.approvedByIds, me.id];

    // Check if everyone approved or admin authorized
    const allApproved = isModerator || req.participantIds.every(id => nextApproved.includes(id));

    if (allApproved) {
      if (req.plan && req.plan.transfers) {
        applyTransfers(req.plan.transfers, req.reason || 'Swap request confirmed');
      }

      setSwapRequests(prev => prev.map(r => 
        r.id === requestId ? { ...r, approvedByIds: nextApproved, state: 'Completed' } : r
      ));

      // 1. Notify all participants
      const participantNotifs: UserNotification[] = req.participantIds.map(id => ({
        id: `notif-approved-${Date.now()}-${id}`,
        userId: id,
        title: 'Shift Swap Finalized!',
        message: `Shift exchange on ${req.targetDate} is approved by all parties. Your schedule is live and updated.`,
        timestamp: new Date().toISOString(),
        read: false,
        type: 'swap-approved',
        actionView: 'roster',
        metadata: {
          date: req.targetDate
        }
      }));

      // 2. REQUIREMENT: Admins should receive notifications for all roster modifications
      const adminAlert: UserNotification = {
        id: `admin-alert-swap-approved-${Date.now()}`,
        userId: 'ADMIN',
        title: 'Admin Alert: Roster Mutation Finalized',
        message: `Shift swap between ${req.participants.join(' and ')} on ${req.targetDate} is finalized and updated on the master roster.`,
        timestamp: new Date().toISOString(),
        read: false,
        type: 'admin-alert',
        actionView: 'history',
        metadata: {
          date: req.targetDate
        }
      };

      const successToast: UserNotification = {
        id: `toast-approved-${Date.now()}`,
        userId: me.id,
        title: 'Swap Finalized & Active',
        message: `The roster schedule for ${req.targetDate} was successfully updated.`,
        timestamp: new Date().toISOString(),
        read: true,
        type: 'swap-approved',
        actionView: 'roster'
      };
      setActiveToast(successToast);

      setNotifications(prev => [...participantNotifs, adminAlert, ...prev]);
    } else {
      setSwapRequests(prev => prev.map(r => 
        r.id === requestId ? { ...r, approvedByIds: nextApproved } : r
      ));

      const agreedToast: UserNotification = {
        id: `toast-agreed-${Date.now()}`,
        userId: me.id,
        title: 'Agreement Recorded',
        message: `You agreed to the swap. Awaiting remaining teammates to finalize.`,
        timestamp: new Date().toISOString(),
        read: true,
        type: 'swap-request',
        actionView: 'swaps'
      };
      setActiveToast(agreedToast);
    }
  };

  // Decline swap request
  const handleDeclineRequest = (requestId: string) => {
    const req = swapRequests.find(r => r.id === requestId);
    setSwapRequests(prev => prev.map(r => 
      r.id === requestId ? { ...r, state: 'Declined' } : r
    ));

    if (req) {
      // Alert participants that trade was declined
      const declineNotifs: UserNotification[] = req.participantIds.map(id => ({
        id: `notif-declined-${Date.now()}-${id}`,
        userId: id,
        title: 'Swap Proposal Declined',
        message: `The swap proposal for ${req.targetDate} was declined by ${currentEmployee.name}.`,
        timestamp: new Date().toISOString(),
        read: false,
        type: 'swap-request',
        actionView: 'swaps'
      }));
      setNotifications(prev => [...declineNotifs, ...prev]);
    }
  };

  // Send message
  const handleSendMessage = (recipientId: string, text: string, shiftAttachment?: any) => {
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      conversationId: recipientId === 'TEAM_LOUNGE' ? 'TEAM_LOUNGE' : [currentEmployee.id, recipientId].sort().join('_'),
      senderId: currentEmployee.id,
      senderName: currentEmployee.name,
      senderInitials: currentEmployee.initials,
      recipientId,
      text,
      timestamp: new Date().toISOString(),
      shiftAttachment
    };

    setMessages(prev => [...prev, newMsg]);

    // Notifications according to destination
    if (recipientId === 'TEAM_LOUNGE') {
      // Broadcast notification to colleagues (excluding me)
      const broadcastNotifs: UserNotification[] = employees
        .filter(e => e.id !== currentEmployee.id)
        .slice(0, 3) // Sample alert for active peers
        .map(e => ({
          id: `notif-team-${Date.now()}-${e.id}`,
          userId: e.id,
          title: `Roster Lounge: ${currentEmployee.name}`,
          message: text.length > 60 ? `${text.slice(0, 60)}...` : text,
          timestamp: new Date().toISOString(),
          read: false,
          type: 'message',
          actionView: 'messages'
        }));
      setNotifications(prev => [...broadcastNotifs, ...prev]);
    } else if (recipientId === 'ADMIN_DESK') {
      // Notify Admin
      const adminMsgNotif: UserNotification = {
        id: `notif-admin-msg-${Date.now()}`,
        userId: 'ADMIN',
        title: `Admin Inbox: Message from ${currentEmployee.name}`,
        message: text.length > 70 ? `${text.slice(0, 70)}...` : text,
        timestamp: new Date().toISOString(),
        read: false,
        type: 'message',
        actionView: 'messages',
        metadata: {
          employeeId: currentEmployee.id,
          employeeName: currentEmployee.name
        }
      };
      setNotifications(prev => [adminMsgNotif, ...prev]);
    } else {
      // Direct peer message
      const notif: UserNotification = {
        id: `notif-msg-${Date.now()}`,
        userId: recipientId,
        title: `New Message from ${currentEmployee.name}`,
        message: text.length > 60 ? `${text.slice(0, 60)}...` : text,
        timestamp: new Date().toISOString(),
        read: false,
        type: 'message',
        actionView: 'messages'
      };
      setNotifications(prev => [notif, ...prev]);
    }

    // Interactive Toast for sender confirmation
    const sentToast: UserNotification = {
      id: `toast-sent-${Date.now()}`,
      userId: currentEmployee.id,
      title: 'Message Sent',
      message: `Your shift coordination message was delivered.`,
      timestamp: new Date().toISOString(),
      read: true,
      type: 'message',
      actionView: 'messages'
    };
    setActiveToast(sentToast);
  };

  // Reset demo
  const handleResetDemo = () => {
    resetAllData();
    setEmployees(loadEmployees());
    setDays(loadDays());
    setSwapRequests(loadRequests());
    setAuditLogs(loadAuditLogs());
    setMessages(loadMessages());
    setNotifications(loadNotifications());
    setMarketPosts(loadMarketPosts());
  };

  // If not logged in, render clean LoginView
  if (!session) {
    return (
      <LoginView
        employees={employees}
        onLoginEmployee={handleLoginEmployee}
        onLoginAdmin={handleLoginAdmin}
      />
    );
  }

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900 selection:bg-teal-500 selection:text-white">
      {/* Responsive Sidebar */}
      <Sidebar
        activeView={activeView}
        userRole={userRole}
        currentEmployee={currentEmployee}
        pendingRequestsCount={pendingRequestsCount}
        unreadMessagesCount={unreadMessagesCount}
        unreadNotifsCount={unreadNotifsCount}
        totalChangesCount={auditLogs.length}
        openMarketPostsCount={openMarketPostsCount}
        mobileMenuOpen={mobileMenuOpen}
        onCloseMobileMenu={() => setMobileMenuOpen(false)}
        onNavigate={(view) => setActiveView(view)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar
          currentEmployee={currentEmployee}
          userRole={userRole}
          unreadNotifsCount={unreadNotifsCount}
          unreadMessagesCount={unreadMessagesCount}
          notifications={relevantNotifs}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onNavigate={(view) => setActiveView(view)}
          onLogout={handleLogout}
          onMarkNotificationsRead={handleMarkNotificationsRead}
          onToggleRole={handleToggleRole}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeView === 'board' && (
            <PersonalBoard
              employee={currentEmployee}
              days={days}
              swapRequests={swapRequests}
              messages={messages}
              auditLogs={auditLogs}
              onOpenSwapModal={handleOpenSwapModal}
              onNavigate={(view) => setActiveView(view)}
            />
          )}

          {activeView === 'roster' && (
            <RosterView
              employee={currentEmployee}
              days={days}
              onOpenSwapModal={handleOpenSwapModal}
            />
          )}

          {activeView === 'market' && (
            <MarketView
              posts={marketPosts}
              marketPosts={marketPosts}
              currentEmployee={currentEmployee}
              allEmployees={employees}
              days={days}
              onCreatePost={handleCreateMarketPost}
              onMatchPost={handleMatchMarketPost}
              onClosePost={handleCloseMarketPost}
              onOpenChatWith={(_empId) => setActiveView('messages')}
              onNavigate={(view) => setActiveView(view)}
            />
          )}

          {activeView === 'swaps' && (
            <SwapDeskView
              requests={swapRequests}
              currentEmployee={currentEmployee}
              allEmployees={employees}
              userRole={userRole}
              onApproveRequest={handleApproveRequest}
              onDeclineRequest={handleDeclineRequest}
              onOpenNewSwap={() => handleOpenSwapModal(0, 'timing-change')}
            />
          )}

          {activeView === 'messages' && (
            <MessagesView
              currentEmployee={currentEmployee}
              allEmployees={employees}
              messages={messages}
              days={days}
              onSendMessage={handleSendMessage}
              onOpenSwapModal={handleOpenSwapModal}
              onSwitchUser={(newId) => setSession({ userId: newId, role: userRole })}
            />
          )}

          {activeView === 'notifications' && (
            <NotificationCenter
              notifications={notifications}
              currentEmployee={currentEmployee}
              userRole={userRole}
              onMarkAllAsRead={handleMarkNotificationsRead}
              onClearAll={handleClearAllNotifications}
              onMarkOneAsRead={handleMarkOneNotificationRead}
              onDeleteOne={handleDeleteOneNotification}
              onNavigate={(view) => setActiveView(view)}
            />
          )}

          {activeView === 'history' && (
            <AuditLogView
              auditLogs={auditLogs}
              currentEmployee={currentEmployee}
              userRole={userRole}
            />
          )}

          {activeView === 'team' && (
            <TeamAvailability
              employees={employees}
              days={days}
            />
          )}

          {activeView === 'admin' && (
            <AdminPortal
              employees={employees}
              days={days}
              auditLogs={auditLogs}
              onUpdateEmployees={setEmployees}
              onUpdateDays={setDays}
              onResetDemo={handleResetDemo}
              onLogChange={(params) => {
                logRosterChange(params);
                setAuditLogs(loadAuditLogs());

                // Alert staff about admin modification
                const rosterNotif: UserNotification = {
                  id: `admin-mutation-notif-${Date.now()}`,
                  userId: params.employeeId === 'ALL' ? 'ALL' : params.employeeId,
                  title: 'Official Roster Modification',
                  message: `Roster on ${params.date} updated by ${params.changedBy}: ${params.previousShift} → ${params.newShift}. Reason: ${params.reason || 'Admin optimization'}`,
                  timestamp: new Date().toISOString(),
                  read: false,
                  type: 'roster-updated',
                  actionView: 'roster'
                };
                setNotifications(prev => [rosterNotif, ...prev]);
                setActiveToast(rosterNotif);
              }}
            />
          )}
        </main>
      </div>

      {/* Interactive Swap & Timing Change Modal */}
      <SwapModal
        isOpen={swapModalConfig.isOpen}
        onClose={() => setSwapModalConfig(prev => ({ ...prev, isOpen: false }))}
        initialDayIndex={swapModalConfig.dayIndex}
        initialTab={swapModalConfig.tab}
        currentEmployee={currentEmployee}
        allEmployees={employees}
        days={days}
        onSubmitPlan={handleSubmitPlan}
        onDirectTimingChange={handleDirectTimingChange}
        onSwapColleagueShift={handleSwapColleagueShift}
        onAdjustEH={handleAdjustEH}
      />

      {/* Floating Live Real-Time Toast Notification */}
      <NotificationToast
        notification={activeToast}
        onDismiss={() => setActiveToast(null)}
        onNavigate={(view) => setActiveView(view)}
      />
    </div>
  );
}
