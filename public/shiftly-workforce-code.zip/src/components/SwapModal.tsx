import React, { useState, useMemo } from 'react';
import { 
  X, 
  ArrowLeftRight, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  ShieldAlert, 
  ShieldCheck, 
  User, 
  Users,
  DollarSign, 
  Plus,
  Minus
} from 'lucide-react';
import { Employee, DaySchedule, ShiftCategory, SwapPlan } from '../types';
import { SHIFT_DEFINITIONS } from '../data/defaultData';
import { 
  checkShiftEligibility, 
  isShiftProtected, 
  generateDayOffPlans, 
  generateTimingChangePlans,
  getDayAvailableShiftsAndStaff 
} from '../utils/rosterEngine';

interface SwapModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDayIndex: number;
  initialTab: 'day-off' | 'timing-change' | 'eh-claim';
  currentEmployee: Employee;
  allEmployees: Employee[];
  days: DaySchedule[];
  onSubmitPlan: (plan: SwapPlan, reason: string) => void;
  onDirectTimingChange: (dayIndex: number, newShift: ShiftCategory, newTiming: string, reason: string) => void;
  onSwapColleagueShift?: (dayIndex: number, targetColleague: Employee, reason: string) => void;
  onAdjustEH: (dayIndex: number, extraHours: number, reason: string) => void;
}

export const SwapModal: React.FC<SwapModalProps> = ({
  isOpen,
  onClose,
  initialDayIndex,
  initialTab,
  currentEmployee,
  allEmployees,
  days,
  onSubmitPlan,
  onDirectTimingChange,
  onSwapColleagueShift,
  onAdjustEH
}) => {
  const [activeTab, setActiveTab] = useState<'day-off' | 'timing-change' | 'eh-claim'>(initialTab);
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(initialDayIndex);
  const [selectedDesiredShift, setSelectedDesiredShift] = useState<ShiftCategory>('Morning');
  const [selectedEHAmount, setSelectedEHAmount] = useState<number>(2);
  const [reason, setReason] = useState<string>('');
  const [groupFilter, setGroupFilter] = useState<'all' | '2' | '3' | '4'>('all');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [submittedMessage, setSubmittedMessage] = useState<string>('');

  // Sync state when props change
  React.useEffect(() => {
    setSelectedDayIndex(initialDayIndex);
    setActiveTab(initialTab);
    setSubmitted(false);
  }, [initialDayIndex, initialTab, isOpen]);

  const currentShift = currentEmployee.schedule[selectedDayIndex] || 'OFF';
  const currentTiming = currentEmployee.timings[selectedDayIndex] || SHIFT_DEFINITIONS[currentShift]?.time || 'Rest Day';
  const currentEH = currentEmployee.extraHours[selectedDayIndex] || 0;
  const currentDay = days[selectedDayIndex];

  // Check if current shift is protected
  const protectedLeave = isShiftProtected(currentShift);

  // Day Off plans (Circular swaps)
  const dayOffPlans = useMemo(() => {
    if (protectedLeave || currentShift === 'OFF') return [];
    return generateDayOffPlans(currentEmployee, selectedDayIndex, allEmployees, days);
  }, [currentEmployee, selectedDayIndex, allEmployees, days, currentShift, protectedLeave]);

  // Timing change plans (Swapping timing with on-duty peers or direct switch)
  const timingPlans = useMemo(() => {
    if (protectedLeave) return [];
    return generateTimingChangePlans(currentEmployee, selectedDayIndex, selectedDesiredShift, allEmployees, days);
  }, [currentEmployee, selectedDayIndex, selectedDesiredShift, allEmployees, days, protectedLeave]);

  // All available shifts and on-duty colleagues for the selected day
  const availableShiftGroups = useMemo(() => {
    return getDayAvailableShiftsAndStaff(selectedDayIndex, allEmployees, currentEmployee);
  }, [selectedDayIndex, allEmployees, currentEmployee]);

  // Filtered Day Off plans
  const filteredDayOffPlans = useMemo(() => {
    if (groupFilter === 'all') return dayOffPlans;
    const size = parseInt(groupFilter, 10);
    return dayOffPlans.filter(p => p.members.length === size);
  }, [dayOffPlans, groupFilter]);

  // Desired shift check for females
  const desiredShiftCheck = useMemo(() => {
    return checkShiftEligibility(currentEmployee, selectedDesiredShift);
  }, [currentEmployee, selectedDesiredShift]);

  if (!isOpen) return null;

  const handleProposePlan = (plan: SwapPlan) => {
    onSubmitPlan(plan, reason || 'Shift coordination via Swap Desk');
    setSubmittedMessage(plan.description);
    setSubmitted(true);
  };

  const handleApplyDirectTiming = () => {
    if (!desiredShiftCheck.eligible) return;
    const def = SHIFT_DEFINITIONS[selectedDesiredShift];
    onDirectTimingChange(selectedDayIndex, selectedDesiredShift, def.time, reason || 'Individual timing adjustment');
    setSubmittedMessage(`Timing successfully updated to ${selectedDesiredShift} (${def.time}) for ${currentDay.dayName} ${currentDay.dayNumber} ${currentDay.month}.`);
    setSubmitted(true);
  };

  const handleSwapWithColleague = (colleague: Employee) => {
    if (onSwapColleagueShift) {
      onSwapColleagueShift(selectedDayIndex, colleague, reason || `Shift timing swap with ${colleague.name}`);
      setSubmittedMessage(`Timing successfully shifted with ${colleague.name} for ${currentDay.dayName}, ${currentDay.dayNumber} ${currentDay.month}.`);
      setSubmitted(true);
    } else {
      const myShift = currentEmployee.schedule[selectedDayIndex];
      const myTime = currentEmployee.timings[selectedDayIndex];
      const theirShift = colleague.schedule[selectedDayIndex];
      const theirTime = colleague.timings[selectedDayIndex];
      const plan: SwapPlan = {
        id: `plan-timing-${Date.now()}`,
        members: [currentEmployee.id, colleague.id],
        type: 'timing-change',
        transfers: [
          {
            fromEmployeeId: currentEmployee.id,
            toEmployeeId: colleague.id,
            dateIndex: selectedDayIndex,
            date: currentDay.date,
            fromShift: myShift,
            fromTiming: myTime,
            toShift: theirShift,
            toTiming: theirTime
          },
          {
            fromEmployeeId: colleague.id,
            toEmployeeId: currentEmployee.id,
            dateIndex: selectedDayIndex,
            date: currentDay.date,
            fromShift: theirShift,
            fromTiming: theirTime,
            toShift: myShift,
            toTiming: myTime
          }
        ],
        description: `Timing Swap: You take ${theirShift} (${theirTime}), ${colleague.name.split(' ')[0]} takes ${myShift} (${myTime}) on ${currentDay.dayName}.`,
        score: 98
      };
      handleProposePlan(plan);
    }
  };

  const handleApplyEH = () => {
    onAdjustEH(selectedDayIndex, selectedEHAmount, reason || 'Extra Hours (EH) paid work adjustment');
    setSubmittedMessage(`Paid Extra Hours updated to ${selectedEHAmount}h for ${currentDay.dayName} ${currentDay.dayNumber} ${currentDay.month}.`);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl rounded-2xl bg-white p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 hover:text-slate-800 transition-colors"
        >
          <X className="h-4 w-4" />
        </button>

        {submitted ? (
          <div className="text-center py-6 space-y-4">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-teal-100 text-teal-600">
              <CheckCircle2 className="h-9 w-9" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900">Request Confirmed!</h3>
            <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
              {submittedMessage}
            </p>
            <div className="rounded-xl bg-slate-50 p-3 text-xs text-slate-500 border border-slate-200 max-w-md mx-auto">
              ✓ Admin notified • Roster changes stored in 30-day audit log • Involves teammates updated
            </div>
            <button
              onClick={onClose}
              className="mt-4 inline-flex items-center justify-center rounded-xl bg-slate-900 px-6 py-2.5 text-xs font-bold text-white hover:bg-slate-800"
            >
              Back to Roster
            </button>
          </div>
        ) : (
          <>
            {/* Header & Target Day Selector */}
            <div className="mb-6">
              <span className="text-[11px] font-bold uppercase tracking-wider text-teal-600">Roster Exchange & Timing</span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5">
                Shift Adjustment Engine
              </h2>
              
              {/* Day selection tabs */}
              <div className="flex gap-1.5 overflow-x-auto mt-3 pb-1">
                {days.map((d, i) => (
                  <button
                    key={d.date}
                    onClick={() => setSelectedDayIndex(i)}
                    className={`flex-1 min-w-[58px] py-1.5 px-2 rounded-lg text-xs font-semibold text-center border transition-all ${
                      selectedDayIndex === i
                        ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span className="block text-[9px] uppercase font-bold text-slate-400">{d.dayName}</span>
                    <span className="text-xs font-bold">{d.dayNumber}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Current Day Context Card */}
            <div className="rounded-xl bg-slate-50 border border-slate-200/80 p-3.5 mb-5 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-400">Selected Assignment</span>
                <p className="text-sm font-bold text-slate-900">
                  {currentDay.dayName}, {currentDay.dayNumber} {currentDay.month} · {currentShift}
                </p>
                <p className="text-xs text-slate-500 font-mono mt-0.5">{currentTiming}</p>
              </div>

              {currentEH > 0 && (
                <span className="rounded-md bg-amber-100 border border-amber-300 px-2 py-1 text-xs font-bold text-amber-900">
                  +{currentEH}h EH Allocated
                </span>
              )}
            </div>

            {/* Protected Leave Block */}
            {protectedLeave ? (
              <div className="rounded-xl bg-rose-50 border border-rose-200 p-4 text-center space-y-2">
                <ShieldAlert className="h-8 w-8 text-rose-600 mx-auto" />
                <h4 className="text-sm font-bold text-rose-900">{currentShift} is Non-Exchangeable</h4>
                <p className="text-xs text-rose-700 max-w-md mx-auto leading-relaxed">
                  Per labor law regulations, statutory parental and maternity leaves are strictly protected. They cannot be swapped, surrendered, or exchanged for other shifts.
                </p>
              </div>
            ) : (
              <>
                {/* 3 Main Functional Tabs */}
                <div className="flex rounded-xl bg-slate-100 p-1 mb-5 border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setActiveTab('timing-change')}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-bold rounded-lg transition-all ${
                      activeTab === 'timing-change'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    <Clock className="h-3.5 w-3.5 text-indigo-600" />
                    <span>Change Shift Timing</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('day-off')}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-bold rounded-lg transition-all ${
                      activeTab === 'day-off'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    <ArrowLeftRight className="h-3.5 w-3.5 text-teal-600" />
                    <span>Take Day Off</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('eh-claim')}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-bold rounded-lg transition-all ${
                      activeTab === 'eh-claim'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    <DollarSign className="h-3.5 w-3.5 text-amber-600" />
                    <span>Extra Hours (EH)</span>
                  </button>
                </div>

                {/* TAB 1: Timing Change */}
                {activeTab === 'timing-change' && (
                  <div className="space-y-4">
                    {/* Shift & Colleague Mode Explanation */}
                    <div className="rounded-xl bg-slate-50 p-3.5 border border-slate-200">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-800">
                          Change Shift Timing for {currentDay.dayName} ({currentDay.date})
                        </span>
                        <span className="text-[11px] font-mono text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200">
                          Current: {currentShift} ({currentTiming})
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Shift timing with colleagues on any available shift for this day, or switch directly. All changes strictly adhere to female timing limits (02:00 to 22:00 max).
                      </p>
                    </div>

                    {/* Section A: All Available Shifts & Colleagues On Duty */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          <Users className="h-4 w-4 text-teal-600" />
                          <span>All Available Shifts & Active Colleagues on {currentDay.dayName}</span>
                        </h4>
                        <span className="text-[10px] font-medium text-slate-500">
                          {availableShiftGroups.length} shifts available
                        </span>
                      </div>

                      <div className="space-y-3">
                        {availableShiftGroups.map(group => {
                          const myEligibility = group.shift === 'OFF' 
                            ? { eligible: true } 
                            : checkShiftEligibility(currentEmployee, group.shift as ShiftCategory);

                          return (
                            <div key={group.shift} className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-2xs">
                              {/* Shift Header */}
                              <div className="flex items-center justify-between bg-slate-50/80 px-3 py-2 border-b border-slate-200 text-xs">
                                <div className="flex items-center gap-2">
                                  <span className="font-extrabold text-slate-900">{group.shift}</span>
                                  <span className="text-[10px] font-mono text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                                    {group.timing}
                                  </span>
                                </div>
                                <span className="text-[11px] font-semibold text-slate-600">
                                  {group.colleagues.length} {group.colleagues.length === 1 ? 'colleague' : 'colleagues'}
                                </span>
                              </div>

                              {/* Colleagues working this shift */}
                              <div className="p-2.5 space-y-2">
                                {group.colleagues.map(colleague => {
                                  // Check if colleague is allowed to take current employee's shift
                                  const colleagueEligibility = currentShift === 'OFF'
                                    ? { eligible: true }
                                    : checkShiftEligibility(colleague, currentShift as ShiftCategory);

                                  const canSwap = myEligibility.eligible && colleagueEligibility.eligible;

                                  let blockerReason = '';
                                  if (!myEligibility.eligible) {
                                    blockerReason = myEligibility.reason || 'Not permitted for your profile';
                                  } else if (!colleagueEligibility.eligible) {
                                    blockerReason = `${colleague.name.split(' ')[0]} cannot take your shift: ${colleagueEligibility.reason}`;
                                  }

                                  return (
                                    <div 
                                      key={colleague.id}
                                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-lg border border-slate-100 p-2.5 bg-slate-50/50 hover:bg-slate-50 transition-colors"
                                    >
                                      <div className="flex items-center gap-2.5">
                                        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-900 text-[10px] font-bold text-white font-mono">
                                          {colleague.initials}
                                        </div>
                                        <div>
                                          <div className="flex items-center gap-1.5">
                                            <span className="text-xs font-bold text-slate-800">{colleague.name}</span>
                                            <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                                              colleague.gender === 'female' 
                                                ? 'bg-rose-100 text-rose-700' 
                                                : 'bg-sky-100 text-sky-700'
                                            }`}>
                                              {colleague.gender === 'female' ? 'Female' : 'Male'}
                                            </span>
                                          </div>
                                          <span className="text-[10px] text-slate-500 block">{colleague.role}</span>
                                        </div>
                                      </div>

                                      <div className="flex items-center gap-2 self-end sm:self-center">
                                        {!canSwap ? (
                                          <span className="text-[10px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-1 rounded-md">
                                            {blockerReason}
                                          </span>
                                        ) : (
                                          <button
                                            onClick={() => handleSwapWithColleague(colleague)}
                                            className="flex items-center gap-1 rounded-lg bg-teal-600 hover:bg-teal-700 px-3 py-1.5 text-xs font-bold text-white shadow-2xs transition-colors"
                                          >
                                            <ArrowLeftRight className="h-3.5 w-3.5" />
                                            <span>Shift Timing with {colleague.name.split(' ')[0]}</span>
                                          </button>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Section B: Direct Shift Switch */}
                    <div className="pt-3 border-t border-slate-200">
                      <h4 className="text-xs font-bold text-slate-800 mb-2">
                        Or Switch Shift Directly:
                      </h4>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-3">
                        {(['Morning', 'Day', 'Evening', 'Night', 'Overnight'] as ShiftCategory[]).map(cat => {
                          const def = SHIFT_DEFINITIONS[cat];
                          const eligibility = checkShiftEligibility(currentEmployee, cat);
                          const isSelected = selectedDesiredShift === cat;

                          return (
                            <button
                              key={cat}
                              type="button"
                              onClick={() => setSelectedDesiredShift(cat)}
                              className={`text-left p-2.5 rounded-xl border transition-all ${
                                isSelected
                                  ? 'border-indigo-600 bg-indigo-50/70 ring-1 ring-indigo-600'
                                  : 'border-slate-200 bg-white hover:bg-slate-50'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-slate-900">{cat}</span>
                                {!eligibility.eligible && (
                                  <span className="text-[10px] text-rose-600 font-bold">Policy Limit</span>
                                )}
                              </div>
                              <span className="block text-[10px] text-slate-500 font-mono mt-0.5">{def.time}</span>
                            </button>
                          );
                        })}
                      </div>

                      {/* Policy warning if not eligible */}
                      {!desiredShiftCheck.eligible ? (
                        <div className="rounded-xl bg-rose-50 border border-rose-200 p-3 flex items-start gap-2.5 text-xs text-rose-800 mb-3">
                          <AlertTriangle className="h-4 w-4 text-rose-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <strong className="block font-bold">Policy Restriction:</strong>
                            <p>{desiredShiftCheck.reason}</p>
                          </div>
                        </div>
                      ) : (
                        <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 flex items-center gap-2 text-xs text-emerald-800 mb-3">
                          <ShieldCheck className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                          <span>Shift conforms to labor limits (02:00–22:00 max constraint).</span>
                        </div>
                      )}

                      <div className="space-y-2">
                        <input
                          type="text"
                          value={reason}
                          onChange={(e) => setReason(e.target.value)}
                          placeholder="Reason / Notes (e.g. Personal schedule coordination)..."
                          className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />

                        <button
                          onClick={handleApplyDirectTiming}
                          disabled={!desiredShiftCheck.eligible}
                          className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all ${
                            desiredShiftCheck.eligible
                              ? 'bg-slate-900 text-white hover:bg-slate-800 shadow-sm'
                              : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                          }`}
                        >
                          Apply Direct Timing Change to {selectedDesiredShift}
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 2: Take Day Off (Circular Permutations) */}
                {activeTab === 'day-off' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">
                          Fair Roster Rotations ({filteredDayOffPlans.length} found)
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          Calculated to preserve queue staffing without creating understaffed queues.
                        </p>
                      </div>

                      {/* Group size filter */}
                      <div className="flex gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-[10px]">
                        {(['all', '2', '3', '4'] as const).map(size => (
                          <button
                            key={size}
                            type="button"
                            onClick={() => setGroupFilter(size)}
                            className={`px-2 py-1 rounded-md font-bold transition-all ${
                              groupFilter === size ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'
                            }`}
                          >
                            {size === 'all' ? 'All' : `${size} People`}
                          </button>
                        ))}
                      </div>
                    </div>

                    {filteredDayOffPlans.length === 0 ? (
                      <div className="rounded-xl bg-slate-50 p-6 text-center border border-slate-200 text-xs text-slate-500">
                        No safe swap permutations found for this date. Check another day or discuss in Messages.
                      </div>
                    ) : (
                      <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                        {filteredDayOffPlans.map(plan => {
                          const members = plan.members.map(id => allEmployees.find(e => e.id === id)).filter(Boolean) as Employee[];

                          return (
                            <div
                              key={plan.id}
                              className="rounded-xl border border-slate-200 bg-white p-3 hover:border-teal-400 transition-all shadow-2xs"
                            >
                              <div className="flex items-center justify-between mb-1.5">
                                <span className="rounded bg-teal-50 text-teal-800 border border-teal-200 px-2 py-0.5 text-[10px] font-bold">
                                  {plan.type === 'direct-2' ? 'Direct 2-Person Swap' : `${plan.members.length}-Way Circular Chain`}
                                </span>
                                <span className="text-[10px] text-emerald-600 font-semibold">✓ Zero Coverage Gap</span>
                              </div>

                              {/* Members route */}
                              <div className="flex items-center gap-1.5 my-2 flex-wrap text-xs font-semibold text-slate-800">
                                {members.map((m, idx) => (
                                  <React.Fragment key={m.id}>
                                    <span className="flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5">
                                      <span className="font-bold">{m.name.split(' ')[0]}</span>
                                      <span className="text-[9px] text-slate-400 font-mono">({m.gender[0].toUpperCase()})</span>
                                    </span>
                                    {idx < members.length - 1 && <span className="text-slate-400">→</span>}
                                  </React.Fragment>
                                ))}
                                <span className="text-slate-400">→</span>
                                <span className="text-slate-500 text-[11px]">Full Rotation Complete</span>
                              </div>

                              <p className="text-xs text-slate-600 mb-2 leading-relaxed">{plan.description}</p>

                              <div className="flex justify-end">
                                <button
                                  onClick={() => handleProposePlan(plan)}
                                  className="rounded-lg bg-teal-500 hover:bg-teal-400 px-3 py-1.5 text-xs font-bold text-slate-950 transition-colors"
                                >
                                  Propose Rotation →
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">
                        Reason for day off request
                      </label>
                      <input
                        type="text"
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                        placeholder="e.g. Urgent family emergency, rest interval requirement..."
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                      />
                    </div>
                  </div>
                )}

                {/* TAB 3: Extra Hours (EH) */}
                {activeTab === 'eh-claim' && (
                  <div className="space-y-4">
                    <div className="rounded-xl bg-amber-50 border border-amber-200 p-3.5 text-xs text-amber-900 leading-relaxed">
                      <strong>About EH (Extra Hours):</strong>
                      <p className="mt-1 text-[11px]">
                        EH represents paid extra work beyond standard shift commitments. You can claim extra hours on rest days (e.g. 4-hour morning burst) or extend shifts for surge call coverage.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-2">
                        Select Extra Hours (EH) to assign on {currentDay.dayName}:
                      </label>
                      <div className="flex items-center gap-3">
                        {[0, 1.5, 2, 3, 4].map(val => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => setSelectedEHAmount(val)}
                            className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                              selectedEHAmount === val
                                ? 'bg-amber-500 text-slate-950 border-amber-600 ring-1 ring-amber-600'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {val === 0 ? 'None (0h)' : `+${val}h EH`}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">
                        Justification / Queue Area
                      </label>
                      <input
                        type="text"
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                        placeholder="e.g. Peak volume surge support, credit card dispute queue..."
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>

                    <button
                      onClick={handleApplyEH}
                      className="w-full py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-colors shadow-xs"
                    >
                      Update Paid Extra Hours ({selectedEHAmount > 0 ? `+${selectedEHAmount}h EH` : 'Clear EH'})
                    </button>
                  </div>
                )}
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
};
