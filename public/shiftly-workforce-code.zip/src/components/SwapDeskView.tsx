import React from 'react';
import { 
  ArrowLeftRight, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ShieldCheck, 
  Users, 
  PlusCircle,
  AlertCircle
} from 'lucide-react';
import { SwapRequest, Employee, DaySchedule } from '../types';

interface SwapDeskViewProps {
  requests: SwapRequest[];
  currentEmployee: Employee;
  allEmployees: Employee[];
  userRole: 'employee' | 'admin';
  onApproveRequest: (requestId: string) => void;
  onDeclineRequest: (requestId: string) => void;
  onOpenNewSwap: () => void;
}

export const SwapDeskView: React.FC<SwapDeskViewProps> = ({
  requests,
  currentEmployee,
  allEmployees,
  userRole,
  onApproveRequest,
  onDeclineRequest,
  onOpenNewSwap
}) => {
  // Filter relevant requests: User is in participants or user is Admin
  const relevantRequests = requests.filter(r => 
    userRole === 'admin' || r.participantIds.includes(currentEmployee.id)
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Mutual Approvals</span>
            <span className="rounded-full bg-slate-200 px-2 py-0.5 text-[10px] font-mono text-slate-700">
              {relevantRequests.length} Total Requests
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Swap Desk & Trade Approvals
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Review proposed shift swaps. When all participating teammates approve, the official roster mutates automatically.
          </p>
        </div>

        <button
          onClick={onOpenNewSwap}
          className="flex items-center gap-1.5 rounded-xl bg-teal-500 hover:bg-teal-400 px-4 py-2.5 text-xs font-bold text-slate-950 transition-colors shadow-xs"
        >
          <PlusCircle className="h-4 w-4" />
          <span>Propose New Swap</span>
        </button>
      </div>

      {/* Requests List */}
      <div className="space-y-3">
        {relevantRequests.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center shadow-xs">
            <ArrowLeftRight className="h-10 w-10 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-900">No active swap proposals</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              You currently have no pending shift exchanges requiring your confirmation.
            </p>
            <button
              onClick={onOpenNewSwap}
              className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800"
            >
              Explore Swap Options →
            </button>
          </div>
        ) : (
          relevantRequests.map(req => {
            const hasApproved = req.approvedByIds.includes(currentEmployee.id);
            const isCompleted = req.state === 'Completed' || req.state === 'Approved';
            const isDeclined = req.state === 'Declined';
            const participantStaff = req.participantIds.map(id => allEmployees.find(e => e.id === id)).filter(Boolean) as Employee[];

            return (
              <div
                key={req.id}
                className={`rounded-2xl border p-5 shadow-xs transition-all ${
                  isCompleted
                    ? 'bg-slate-50/60 border-slate-200'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                      isCompleted ? 'bg-emerald-100 text-emerald-800' :
                      isDeclined ? 'bg-rose-100 text-rose-800' :
                      'bg-amber-100 text-amber-900'
                    }`}>
                      {req.state}
                    </span>
                    <span className="text-xs font-bold text-slate-700">
                      Initiated by {req.requesterName}
                    </span>
                  </div>

                  <span className="text-[11px] text-slate-400 font-mono">
                    {new Date(req.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {/* Body Details */}
                <div className="py-3">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <Users className="h-4 w-4 text-slate-400" />
                    <span className="text-xs font-bold text-slate-800">Involved Colleagues:</span>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {participantStaff.map(p => {
                        const approved = req.approvedByIds.includes(p.id);
                        return (
                          <span
                            key={p.id}
                            className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-md border ${
                              approved ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-slate-100 text-slate-700 border-slate-200'
                            }`}
                          >
                            <span>{p.name}</span>
                            {approved ? (
                              <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                            ) : (
                              <Clock className="h-3 w-3 text-amber-500" />
                            )}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  {/* Plan description */}
                  {req.plan && (
                    <p className="text-xs text-slate-600 leading-relaxed mt-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <strong>Rotation Route:</strong> {req.plan.description}
                    </p>
                  )}

                  {req.reason && (
                    <p className="text-[11px] text-slate-500 italic mt-2">
                      Reason: "{req.reason}"
                    </p>
                  )}
                </div>

                {/* Actions */}
                {!isCompleted && !isDeclined && (
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2">
                    <span className="text-xs text-slate-500">
                      Progress: {req.approvedByIds.length} of {req.participantIds.length} approvals
                    </span>

                    <div className="flex items-center gap-2">
                      {hasApproved && userRole !== 'admin' ? (
                        <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                          <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                          <span>You agreed (Awaiting remaining teammates)</span>
                        </span>
                      ) : (
                        <>
                          <button
                            onClick={() => onDeclineRequest(req.id)}
                            className="px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 transition-colors"
                          >
                            Decline
                          </button>
                          <button
                            onClick={() => onApproveRequest(req.id)}
                            className="px-4 py-1.5 rounded-xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 shadow-xs transition-colors"
                          >
                            {userRole === 'admin' ? 'Authorize & Apply Roster Mutation' : 'Confirm & Agree to Swap'}
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
